package br.com.walkito.maisVida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaisVidaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaisVidaApplication.class, args);
	}

}
