package br.com.walkito.maisVida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaisVidaApplicationTests {

	@Test
	void contextLoads() {
	}

}
